# Type of maze to use.
# 0 - Pac-Man
# 1 - Ms. Pac-Man 1
maze_type = 0

# Scale of the maze (and rest of the game).
maze_scale = 40

# How fast ghosts move.
# Can be set to 0 to freeze them.
rival_speed = 2

# Rival AI type.
# 0 - minimax (alpha-beta no pruning)
# 1 - alpha-beta (w/ pruning)
ai_type = "alpha-beta"

# Optional simulator-based planning layer for battle action suggestions.
use_planning = True
planner_method = "forward"
plan_tolerance = 50
planner_max_expansions = 2500
