import os
import pygame
import asyncio
from copy import deepcopy
import config
import maze
import battle
import selection

import heapq
from itertools import count

from collections import deque

ROOT = os.path.dirname(os.path.abspath(__file__))
original_speed = config.rival_speed


def dist(p1, p2):
    return abs(p1[0] - p2[0]) + abs(p1[1] - p2[1])


window_size = (950, 600)


class Character:
    pos = pygame.Vector2(0, 0)

    # pattern:
    # idle, walk1, walk2
    sprites = []

    # direction (1-4, right left up down)
    dir = 0
    walk_frame = 0
    moving = False
    moving_dir = 0

    # the points to traverse
    path = [maze.points[1][1]]
    queue = []
    queue_curr = 0

    # 2 - A* (rival)
    # 5 - player
    ai_type = 0

    def __init__(self, point, name, ai_type):
        self.pos = pygame.Vector2(point.spos(), point.spos())
        self.path = [point]
        self.sprites = []
        self.last_point = point
        self.ai_type = ai_type
        self.last_target_point = point
        self.walk_frame = 0
        self.moving = False
        self.moving_dir = -1
        for i in range(12):
            sprite = pygame.image.load(f"{ROOT}/assets/{name}/{name}_{i}.png")
            self.sprites.append(sprite)

    def ai(self):
        # safeguard: stay at last point if there's no path
        if len(self.path) == 0:
            self.path = [self.last_point]

        # current point
        point = deepcopy(self.path[0])

        self.moving = False

        # move ghost to their npi
        #
        # when moving, always check against ghost and point pos to ensure
        # that ghost lands on the point instead of overshooting
        if self.pos.x > point.spos().x:
            self.pos.x -= min(config.rival_speed, abs(point.spos().x - self.pos.x))
            self.moving = True
            self.dir = 2
        elif self.pos.x < point.spos().x:
            self.pos.x += min(config.rival_speed, abs(point.spos().x - self.pos.x))
            self.moving = True
            self.dir = 3

        if self.pos.y > point.spos().y:
            self.pos.y -= min(config.rival_speed, abs(point.spos().y - self.pos.y))
            self.moving = True
            self.dir = 1
        elif self.pos.y < point.spos().y:
            self.pos.y += min(config.rival_speed, abs(point.spos().y - self.pos.y))
            self.moving = True
            self.dir = 0

        if self.moving:
            self.walk_frame += 1
        else:
            self.walk_frame = 0

        # move to next point if ghost is close to its current
        if dist(point.spos(), self.pos) < 1:
            # initiate dialog if rival is near player
            if self.ai_type == 2 and (self.pos - characters[0].pos).magnitude() < 45:
                battle.battle_text = "I heard you haven't invested in\nOpenAI. Are you one of those\n'pencil-sloppers'?"
                return

            # prepare points for ghost AI
            for y in range(len(maze.points)):
                for x in range(len(maze.points[y])):
                    maze.points[y][x].prio = -1

            self.last_point = maze.points[int(self.path[0].pos.y)][
                int(self.path[0].pos.x)
            ]
            self.last_point.prio = 0

            # process AI based on type
            match self.ai_type:
                # case 0:
                #     self.path = []
                #     self.dummy(self.last_point, pygame.mouse.get_pos())
                case 1:
                    self.path = []
                    self.queue = []
                    self.queue_curr = 0
                    if hasattr(self, "target_point"):
                        del self.target_point
                    self.ucs_explore(self.last_point)
                    if hasattr(self, "target_point"):
                        self.ucs_path(self.target_point)
                        self.path.reverse()
                        # print(self.path[0].pos)
                case 2:
                    self.path = []
                    self.queue = []
                    self.queue_curr = 0

                    if hasattr(self, "target_point"):
                        del self.target_point

                    self.astar_explore(self.last_point)

                    if hasattr(self, "target_point"):
                        self.ucs_path(self.target_point)
                        self.path.reverse()
                case 3:
                    self.path = []
                    self.queue = []
                    self.queue_curr = 0

                    if hasattr(self, "target_point"):
                        del self.target_point

                    self.greedy_explore(self.last_point)

                    if hasattr(self, "target_point"):
                        self.ucs_path(self.target_point)
                        self.path.reverse()
                case 0:
                    self.path = []
                    self.queue = []
                    self.queue_curr = 0

                    if hasattr(self, "target_point"):
                        del self.target_point

                    self.bfs_explore(self.last_point)

                    if hasattr(self, "target_point"):
                        self.ucs_path(self.target_point)
                        self.path.reverse()
                case 5:
                    path_pos = self.path[0].pos
                    point = maze.Point((path_pos.x, path_pos.y), False)
                    if self.moving_dir != -1:
                        self.dir = self.moving_dir
                    match self.moving_dir:
                        case 0:
                            point = maze.Point((path_pos.x, path_pos.y + 1), False)
                        case 1:
                            point = maze.Point((path_pos.x, path_pos.y - 1), False)
                        case 2:
                            point = maze.Point((path_pos.x - 1, path_pos.y), False)
                        case 3:
                            point = maze.Point((path_pos.x + 1, path_pos.y), False)
                    if not maze.points[int(point.pos.y)][int(point.pos.x)].wall:
                        self.path = [point]

    # from GPT 5.6 (using main.py and maze.py as context)
    def astar_explore(self, start):
        frontier = []
        tie_breaker = count()
        target_pos = characters[0].pos

        def heuristic(point):
            return dist(point.spos(), target_pos)

        start.prio = 0
        self.queue = []

        heapq.heappush(
            frontier,
            (heuristic(start), next(tie_breaker), 0, start),
        )

        while frontier:
            _, _, cost, point = heapq.heappop(frontier)

            # Ignore stale entries after a cheaper route was found.
            if cost != point.prio:
                continue

            self.queue.append(point)

            if dist(target_pos, point.spos()) < 10:
                self.target_point = point
                return

            neighbors = (
                getattr(point, "right", None),
                getattr(point, "left", None),
                getattr(point, "top", None),
                getattr(point, "bottom", None),
            )

            for neighbor in neighbors:
                if neighbor is None:
                    continue

                new_cost = cost + 1

                if neighbor.prio == -1 or new_cost < neighbor.prio:
                    neighbor.prio = new_cost
                    priority = new_cost + heuristic(neighbor)

                    heapq.heappush(
                        frontier,
                        (priority, next(tie_breaker), new_cost, neighbor),
                    )

    # from GPT 5.6 (using main.py and maze.py as context)
    # Osman's first attempt made a FIFO list by accident
    def ucs_explore(self, start):
        frontier = []
        tie_breaker = count()

        start.prio = 0
        self.queue = []

        heapq.heappush(
            frontier,
            (0, next(tie_breaker), start),
        )

        target_pos = pygame.mouse.get_pos()

        while frontier:
            cost, _, point = heapq.heappop(frontier)

            # Ignore stale entries left behind after a cheaper route was found.
            if cost != point.prio:
                continue

            self.queue.append(point)

            if dist(target_pos, point.spos()) < 10:
                self.target_point = point
                return

            neighbors = (
                getattr(point, "right", None),
                getattr(point, "left", None),
                getattr(point, "top", None),
                getattr(point, "bottom", None),
            )

            for neighbor in neighbors:
                if neighbor is None:
                    continue

                new_cost = cost + 1

                if neighbor.prio == -1 or new_cost < neighbor.prio:
                    neighbor.prio = new_cost

                    heapq.heappush(
                        frontier,
                        (new_cost, next(tie_breaker), neighbor),
                    )

    def greedy_explore(self, start):
        frontier = []
        tie_breaker = count()
        target_pos = pygame.mouse.get_pos()

        start.prio = 0
        self.queue = []

        heuristic = lambda point: dist(point.spos(), target_pos)

        heapq.heappush(
            frontier,
            (heuristic(start), next(tie_breaker), 0, start),
        )

        while frontier:
            _, _, cost, point = heapq.heappop(frontier)

            # Ignore stale entries after a cheaper route was found.
            if cost != point.prio:
                continue

            self.queue.append(point)

            if dist(target_pos, point.spos()) < 10:
                self.target_point = point
                return

            neighbors = (
                getattr(point, "right", None),
                getattr(point, "left", None),
                getattr(point, "top", None),
                getattr(point, "bottom", None),
            )

            for neighbor in neighbors:
                if neighbor is None:
                    continue

                new_cost = cost + 1

                if neighbor.prio == -1 or new_cost < neighbor.prio:
                    neighbor.prio = new_cost

                    # Greedy best-first uses only h(n), unlike A*'s g(n) + h(n).
                    heapq.heappush(
                        frontier,
                        (heuristic(neighbor), next(tie_breaker), new_cost, neighbor),
                    )

    def bfs_explore(self, start):
        frontier = deque([start])
        target_pos = pygame.mouse.get_pos()

        start.prio = 0
        self.queue = []

        while frontier:
            point = frontier.popleft()
            self.queue.append(point)

            if dist(target_pos, point.spos()) < 10:
                self.target_point = point
                return

            neighbors = (
                getattr(point, "right", None),
                getattr(point, "left", None),
                getattr(point, "top", None),
                getattr(point, "bottom", None),
            )

            for neighbor in neighbors:
                if neighbor is None or neighbor.prio != -1:
                    continue

                neighbor.prio = point.prio + 1
                frontier.append(neighbor)

    def ucs_path(self, point):
        next_point = point
        closest = point.prio

        # if hasattr(point, "right"):
        #     print("r", point.right.prio)
        # if hasattr(point, "left"):
        #     print("l", point.left.prio)
        # if hasattr(point, "top"):
        #     print("t", point.top.prio)
        # if hasattr(point, "bottom"):
        #     print("b", point.bottom.prio)

        # go to neighbor with smallest prio
        if (
            hasattr(point, "right")
            and point.right.prio != -1
            and point.right.prio < closest
        ):
            next_point = point.right
            closest = point.right.prio
        if (
            hasattr(point, "left")
            and point.left.prio != -1
            and point.left.prio < closest
        ):
            next_point = point.left
            closest = point.left.prio
        if hasattr(point, "top") and point.top.prio != -1 and point.top.prio < closest:
            next_point = point.top
            closest = point.top.prio
        if (
            hasattr(point, "bottom")
            and point.bottom.prio != -1
            and point.bottom.prio < closest
        ):
            next_point = point.bottom
            closest = point.bottom.prio

        if next_point.pos == point.pos:
            return
        self.path.append(point)
        self.ucs_path(next_point)

    # recursively find the closest point to target
    def dummy(self, next_point, target):
        mouse = pygame.mouse.get_pos()

        # find next point's closest neighbor to target
        closest_point = next_point
        closest = dist(mouse, closest_point.spos())

        if hasattr(next_point, "right"):
            distance = dist(mouse, next_point.right.spos())
            if distance < closest:
                closest_point = next_point.right
                closest = dist(mouse, closest_point.spos())

        if hasattr(next_point, "left"):
            distance = dist(mouse, next_point.left.spos())
            if distance < closest:
                closest_point = next_point.left
                closest = dist(mouse, closest_point.spos())

        if hasattr(next_point, "top"):
            distance = dist(mouse, next_point.top.spos())
            if distance < closest:
                closest_point = next_point.top
                closest = dist(mouse, closest_point.spos())

        if hasattr(next_point, "bottom"):
            distance = dist(mouse, next_point.bottom.spos())
            if distance < closest:
                closest_point = next_point.bottom
                closest = dist(mouse, closest_point.spos())

        if closest_point != next_point:
            closest_point.prio = next_point.prio + 1
            self.path.append(closest_point)
            self.dummy(closest_point, mouse)

    def draw(self, screen):
        sprite_idx = self.dir * 3
        if self.moving:
            if self.walk_frame < 15 / config.rival_speed:
                sprite_idx += 1
            elif self.walk_frame < 30 / config.rival_speed:
                sprite_idx += 0
            elif self.walk_frame < 45 / config.rival_speed:
                sprite_idx += 2
            elif self.walk_frame < 60 / config.rival_speed:
                sprite_idx += 0
            else:
                self.walk_frame = 0
        sprite = self.sprites[sprite_idx]
        scaled = pygame.transform.scale(
            sprite,
            (
                sprite.get_width() * config.maze_scale / 13,
                sprite.get_height() * config.maze_scale / 13,
            ),
        )
        rect = scaled.get_rect()
        rect.x = self.pos.x - rect.height / 2
        rect.y = self.pos.y - rect.width / 2
        screen.blit(scaled, rect)

    def draw_points(self, screen):
        font = pygame.font.SysFont("Arial", 16)
        highest_queue_prio = 1
        for queue in self.queue:
            highest_queue_prio = max(highest_queue_prio, queue.prio)
        highest_path_prio = 1
        for path in self.path:
            highest_path_prio = max(highest_path_prio, path.prio)
        for y in range(len(maze.points)):
            for x in range(len(maze.points[y])):
                if maze.points[y][x].wall:
                    continue
                pos = deepcopy(maze.points[y][x].pos)

                # use different points if this point is in the queue, path, or is target
                col = "#dda49c"
                if hasattr(self, "target_point") and self.target_point.pos == pos:
                    col = "green"
                else:
                    for queue in self.queue:
                        if queue.pos == pos:
                            col = "blue" if config.maze_type == 0 else "magenta"
                    for path in self.path:
                        if path.pos == pos:
                            col = "red"
                pos *= config.maze_scale
                pos.x += config.maze_scale / 2
                pos.y += config.maze_scale / 2

                pos.x -= 7.5
                pos.y -= 7.5

                screen.blit(font.render(str(maze.points[y][x].prio), True, col), pos)
                # use different color if this point is in the expanded list
                # pygame.draw.circle(screen, col, pos, 3, 5)

    def stats(self, screen):
        row = 10
        font = pygame.font.SysFont("Arial", 24)
        self.stat("Expanded:", len(self.queue), row, screen, font, "white")
        path_cost = "-"
        if len(self.path) > 0:
            path_cost = self.path[len(self.path) - 1].prio
        row += 40
        self.stat("Path Cost:", path_cost, row, screen, font, "white")

    def help(self, screen):
        row = 130
        font = pygame.font.SysFont("Arial", 24)
        self.stat("Controls:", "", row, screen, font, "white")
        row += 40
        self.stat("A*:", 1, row, screen, font, "red")
        row += 40
        self.stat("UCS:", 2, row, screen, font, "magenta")
        row += 40
        self.stat("BFS:", 3, row, screen, font, "cyan")
        row += 40
        self.stat("Greedy:", 4, row, screen, font, "orange")
        row += 40
        self.stat("All:", 5, row, screen, font, "White")

    def stat(self, left_str, right_str, y, screen, font, col):
        text_surface = font.render(left_str, True, col)
        text_rect = text_surface.get_rect(topleft=(570, y))
        screen.blit(text_surface, text_rect)

        text_surface = font.render(str(right_str), True, col)
        text_rect = text_surface.get_rect(topright=(window_size[0] - 10, y))
        screen.blit(text_surface, text_rect)


# initialize characters
characters = []
characters.append(Character(maze.points[11][10], "player", 5))
characters.append(Character(maze.points[3][7], "rival", 2))


def draw_points(screen):
    for y in range(len(maze.points)):
        for x in range(len(maze.points[y])):
            if maze.points[y][x].wall:
                continue
            pos = deepcopy(maze.points[y][x].pos)
            col = "#dda49c"
            pos *= config.maze_scale
            pos.x += config.maze_scale / 2
            pos.y += config.maze_scale / 2
            pygame.draw.circle(screen, col, pos, 3, 5)


def next_step():
    battle.advance_battle()


async def main():
    pygame.init()
    screen = pygame.display.set_mode((int(window_size[0]), int(window_size[1])))
    clock = pygame.time.Clock()
    running = True
    maze_og_toggle = True
    active_ghost = 0
    noticed = False
    font = pygame.font.Font("assets/pkmn.ttf", 24)
    stat_font = pygame.font.Font("assets/pkmn.ttf", 18)
    state = "overworld"

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    if state == "battle":
                        if battle.showing_planning:
                            battle.planning_trace_step = max(
                                battle.planning_trace_step - 1, 0
                            )
                        elif battle.showing_kb and battle.inference_result:
                            battle.kb_trace_step = max(
                                battle.kb_trace_step - 1, 0
                            )
                    elif state == "select":
                        if selection.show_csp_debug_overlay:
                            selection.move_csp_debug_step(-1)
                        elif (
                            selection.show_debug_overlay
                            or selection.show_uncertainty_overlay
                        ):
                            selection.move_debug_step(-1)
                        else:
                            selection.selected = max(selection.selected - 1, 0)
                    elif state == "overworld" and battle.battle_text == "":
                        characters[0].moving_dir = 1
                elif event.key == pygame.K_DOWN:
                    if state == "battle":
                        if battle.showing_planning:
                            step_count = (
                                len(battle.last_planning.result.steps)
                                if battle.last_planning
                                and battle.last_planning.result
                                else 0
                            )
                            battle.planning_trace_step = min(
                                battle.planning_trace_step + 1,
                                max(step_count - 1, 0),
                            )
                        elif battle.showing_kb and battle.inference_result:
                            battle.kb_trace_step = min(
                                battle.kb_trace_step + 1,
                                max(len(battle.inference_result.evaluations) - 1, 0),
                            )
                    elif state == "select":
                        if selection.show_csp_debug_overlay:
                            selection.move_csp_debug_step(1)
                        elif (
                            selection.show_debug_overlay
                            or selection.show_uncertainty_overlay
                        ):
                            selection.move_debug_step(1)
                        else:
                            selection.selected = min(selection.selected + 1, 2)
                    elif state == "overworld" and battle.battle_text == "":
                        characters[0].moving_dir = 0
                elif event.key == pygame.K_LEFT:
                    if state == "select":
                        selection.prev_pokemon()
                    elif state == "overworld" and battle.battle_text == "":
                        characters[0].moving_dir = 2
                elif event.key == pygame.K_RIGHT:
                    if state == "select":
                        selection.next_pokemon()
                    elif state == "overworld" and battle.battle_text == "":
                        characters[0].moving_dir = 3
                elif (
                    event.key == pygame.K_w
                    and state == "battle"
                    and battle.move_logs
                ):
                    battle.chosen_log = min(
                        battle.chosen_log + 1, len(battle.move_logs) - 1
                    )
                elif (
                    event.key == pygame.K_q
                    and state == "battle"
                    and battle.move_logs
                ):
                    battle.chosen_log = max(battle.chosen_log - 1, 0)
                elif event.key == pygame.K_SPACE:
                    if state == "battle":
                        next_step()
                    elif state == "select":
                        if not selection.rival_chooses:
                            selection.choose_rival_team()
                            selection.choose_rival_team_old()
                            selection.rival_chooses = True
                        else:
                            battle.start_battle()
                            state = "battle"
                    elif battle.battle_text != "":
                        state = "select"
                elif event.key == pygame.K_i and state == "battle":
                    battle.showing_kb = not battle.showing_kb
                    if battle.showing_kb:
                        battle.showing_nodes = False
                        battle.showing_planning = False
                elif event.key == pygame.K_n and state == "battle":
                    battle.showing_nodes = not battle.showing_nodes
                    if battle.showing_nodes:
                        battle.showing_kb = False
                        battle.showing_planning = False
                elif event.key == pygame.K_p and state == "battle":
                    battle.showing_planning = not battle.showing_planning
                    if battle.showing_planning:
                        battle.showing_kb = False
                        battle.showing_nodes = False
                elif event.key == pygame.K_m:
                    if state == "select":
                        selection.show_debug_overlay = not selection.show_debug_overlay
                        if selection.show_debug_overlay:
                            selection.show_csp_debug_overlay = False
                            selection.show_uncertainty_overlay = False
                    else:
                        maze_og_toggle = not maze_og_toggle
                        battle.showing_log = not battle.showing_log
                elif event.key == pygame.K_c and state == "select":
                    selection.show_csp_debug_overlay = (
                        not selection.show_csp_debug_overlay
                    )
                    if selection.show_csp_debug_overlay:
                        selection.show_debug_overlay = False
                        selection.show_uncertainty_overlay = False
                elif event.key == pygame.K_F3 and state == "select":
                    selection.show_uncertainty_overlay = (
                        not selection.show_uncertainty_overlay
                    )
                    if selection.show_uncertainty_overlay:
                        selection.show_debug_overlay = False
                        selection.show_csp_debug_overlay = False
                elif event.key == pygame.K_ESCAPE:
                    running = False

            elif event.type == pygame.KEYUP:
                if state == "overworld" and event.key in (
                    pygame.K_UP,
                    pygame.K_DOWN,
                    pygame.K_LEFT,
                    pygame.K_RIGHT,
                ):
                    characters[0].moving_dir = -1

        if state == "overworld":
            screen.fill("black")
        elif state == "battle" or state == "select":
            screen.fill("white")

        if state == "overworld":
            img_to_use = maze.maze_og_img if maze_og_toggle else maze.img
            divisor = 16.0 if maze_og_toggle else 1.0
            final_img = pygame.transform.scale(
                img_to_use,
                (
                    img_to_use.get_width() * config.maze_scale / divisor,
                    img_to_use.get_height() * config.maze_scale / divisor,
                ),
            )
            screen.blit(final_img, maze.rect)

            # draw_points(screen)
            characters[1].draw(screen)
            characters[0].draw(screen)
            characters[0].ai()
            if battle.battle_text != "":
                battle.draw_battle_text(screen, font)

            if noticed:
                characters[1].ai()
            elif abs(characters[0].pos.x) == abs(characters[1].pos.x) or abs(
                characters[0].pos.y
            ) == abs(characters[1].pos.y):
                noticed = True
        elif state == "battle":
            battle.draw_pokemon(screen, stat_font)
            battle.draw_battle_text(screen, font)
            # if battle.showing_log:
            #     battle.draw_logs(screen, font)
            # else:
            #     battle.draw_ai_brain(screen, font)
            if battle.showing_nodes:
                battle.node_overlay(screen, font)
            if battle.showing_kb:
                battle.draw_kb_overlay(screen, font)
            if battle.showing_planning:
                battle.draw_planning_overlay(screen, font)
        elif state == "select":
            selection.draw(screen, font)
            selection.draw_pkmn_stats(screen, font)
            selection.draw_debug_overlay(screen)
            selection.draw_csp_debug_overlay(screen)
            selection.draw_uncertainty_overlay(screen)

        pygame.display.flip()
        # print(pygame.mouse.get_pos())

        clock.tick(60)
        await asyncio.sleep(0)


if __name__ == "__main__":
    asyncio.run(main())
